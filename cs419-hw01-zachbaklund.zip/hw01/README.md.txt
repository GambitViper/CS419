Zachary Baklund
Assignment #1

Python 3.7

python ./decision-tree.py